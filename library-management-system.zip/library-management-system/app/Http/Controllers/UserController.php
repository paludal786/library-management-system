<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use App\Models\User;
use App\Models\Book;


class UserController extends Controller
{
    //

    public function AddUser(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'firstname' => 'required|string',
            'lastname' => 'required|string',
            'mobile' => [
                'required',
                Rule::unique('users')->where(function ($query) {
                    $query->whereNull('deleted_at');
                }),
            ],
            'email' => [
                'required',
                Rule::unique('users')->where(function ($query) {
                    $query->whereNull('deleted_at');
                }),
            ],
            'age' => 'required',
            'gender' => 'required|string',
            'city' => 'required|string',
            'password' => 'required|string'
        ]);

        if ($validator->fails()) {
            return response($validator->errors(), 422);
        }

        $user = new User();

        $user->firstname = $request->firstname;
        $user->lastname = $request->lastname;
        $user->mobile = $request->mobile;
        $user->email = $request->email;
        $user->age = $request->age;
        $user->gender = $request->gender;
        $user->city = $request->city;
        $user->password = bcrypt($request->password);

        $user->save();

        $data = [];
        $data['data'] = $user;
        $data['status'] = true;

        return response($data, 200);

    }

    public function UpdateUser(Request $request, $u_id)
    {

        $validator = Validator::make($request->all(), [
            'firstname' => 'required|string',
            'lastname' => 'required|string',
            'mobile' => [
                'required',
            ],
            'email' => [
                'required',
            ],
            'age' => 'required',
            'gender' => 'required|string',
            'city' => 'required|string',
            'password' => 'required|string'
        ]);

        if ($validator->fails()) {
            return response($validator->errors(), 422);
        }

        $user = User::where('u_id',$u_id)->firstOrFail();

        $user->firstname = $request->firstname;
        $user->lastname = $request->lastname;
        $user->mobile = $request->mobile;
        $user->email = $request->email;
        $user->age = $request->age;
        $user->gender = $request->gender;
        $user->city = $request->city;
        $user->password = bcrypt($request->password);

        User::where('u_id',$u_id)->update($user->toArray());

        $data = [];
        $data['data'] = $user;
        $data['status'] = true;

        return response($data, 200);

    }

    public function DeleteUser($id)
    {
        $deleteUser = User::where('u_id', $id)->delete();
        if ($deleteUser) {
            $data = [];
            $data['result'] = 'User Deleted Successfully';
            $data['status'] = true;
            return response($data, 200);
        }else{
            $data = [];
            $data['result'] = 'User Id Not Found';
            $data['status'] = false;
            return response($data, 404);
        }
    }

    public function UserList(Request $request)
    {
        $data = [];
        $data['data'] = User::all();
        $data['status'] = true;
        return response($data);
    }

    public function ListPerticularUser($id)
    {
        $listPerticularUser = User::where('u_id',$id)->get()->toArray();
        if (empty($listPerticularUser)) {
            $data = [];
            $data['data'] = 'Data Not Found';
            $data['status'] = false;
            return response($data, 404);
        } else {
            $data = [];
            $data['data'] = $listPerticularUser;
            $data['status'] = true;
            return response($data, 200);
        }
    }

    public function LoginUser(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required',
            'password' => 'required|string'
        ]);

        if ($validator->fails()) {
            return response($validator->errors(), 422);
        }

        $user_email = $request->email;
        $user_password = base64_encode($request->password);

        $user = User::where([
            ['email', '=', $user_email],
            ['password', '=',$user_password]
        ])->first();

        if ($user) {

            return response()->json([
                "success" => true,
                "message" => "Welcome Back ". $user->firstname . " !",
                "data" => $user
            ]);

        } else {
            return response()->json([
                "success" => false,
                "message" => "Invalid Email/Password",
                "data" => []
            ]);
        }
    }

    public function UserProfile($id)
    {
        $listPerticularUserProfileDetails = User::where('u_id',$id)->first();

        if ($listPerticularUserProfileDetails) {
            return response()->json(['data' => $listPerticularUserProfileDetails, 'status' => true], 200);
        } else {
            return response()->json(['data' => [], 'status' => false], 404);
        }

    }

    public function IssueBook(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'b_id' => [
                'required' ,
                Rule::exists('books', 'b_id')->where(function ($query) {
                    $query->whereNull('deleted_at');
                })
            ],
            'u_id' => [
                'required' ,
                Rule::exists('users', 'u_id')->where(function ($query) {
                    $query->whereNull('deleted_at');
                })
            ]
        ]);

        if ($validator->fails()) {
            return response($validator->errors(), 422);
        }

        $user = new User();
        $user->books()->attach([['u_id' =>  $request->u_id, 'b_id' => $request->b_id, 'status' => 'issued']]);

        return response()->json([
            'message' => 'book issued',
            'status' => true
        ]);

    }

    public function ReturnBook(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'b_id' => [
                'required' ,
                Rule::exists('books', 'b_id')->where(function ($query) {
                    $query->whereNull('deleted_at');
                })
            ],
            'u_id' => [
                'required' ,
                Rule::exists('users', 'u_id')->where(function ($query) {
                    $query->whereNull('deleted_at');
                })
            ]
        ]);

        if ($validator->fails()) {
            return response($validator->errors(), 422);
        }

        $users  = User::where('u_id', $request->u_id)->get();
        foreach($users as $user)
        $user->books()->sync([['u_id' =>  $request->u_id, 'b_id' => $request->b_id, 'status' => 'return']]);


        return response()->json([
            'message' => 'book return',
            'status' => true
        ]);

    }

    public function ShowBookDetailsByUserWise()
    {
        $users = User::with(['books' => function($query){
               $query->wherePivot('status','issued');
        }])->get();

        return response()->json([
            'message' => 'user wise books',
            'data' => $users,
            'status' => true
        ]);

    }

}
