<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use App\Models\Book;

class BookController extends Controller
{
    //

    public function StoreBook(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'book_name' => 'required|string',
            'author' => 'required|string',
            'cover_image' => 'required|mimes:png,jpeg|max:2048'
        ]);

        if ($validator->fails()) {
            return response($validator->errors(), 422);
        }

        if ($files = $request->file('cover_image')) {

            $book = new Book();
            \Storage::disk('local')->put('images/' . $files->getClientOriginalName() ,$request->file);

            $book->book_name = $request->book_name;
            $book->author = $request->author;
            $book->cover_image = $files->getClientOriginalName();
            $book->save();


            return response()->json([
                "success" => true,
                "message" => "File successfully uploaded",
                "data" => $book
            ]);

        }else{
            return response()->json([
                "success" => false,
                "message" => "Please Select File Required",
                "data" => []
            ]);
        }


    }

    public function UpdateBook(Request $request,$b_id)
    {
        $validator = Validator::make($request->all(), [
            'book_name' => 'required|string',
            'author' => 'required|string',
            'cover_image' => 'required|mimes:png,jpeg|max:2048'
        ]);

        if ($validator->fails()) {
            return response($validator->errors(), 422);
        }

        if ($files = $request->file('cover_image')) {

            $book = Book::where('b_id',$b_id)->firstOrFail();


            \Storage::disk('local')->put('images/' . $files->getClientOriginalName() ,$request->file);

            $book->book_name = $request->book_name;
            $book->author = $request->author;
            $book->cover_image = $files->getClientOriginalName();
            Book::where('b_id',$b_id)->update($book->toArray());

            return response()->json([
                "success" => true,
                "message" => "successfully updated",
                "data" => $book
            ]);

        }else{
            return response()->json([
                "success" => false,
                "message" => "Please Select File Required",
                "data" => []
            ]);
        }
    }

    public function DeleteBook($id)
    {
        $deleteBook = Book::where('b_id', $id)->delete();
        if ($deleteBook) {
            $data = [];
            $data['result'] = 'Book Deleted Successfully';
            $data['status'] = true;
            return response()->json($data);
        }else{
            $data = [];
            $data['result'] = 'Book Id Not Found';
            $data['status'] = false;
            return response()->json($data);
        }
    }

    public function BookList(Request $request)
    {
        $data = [];
        $data['data'] = Book::all();
        $data['status'] = true;
        return response()->json($data);
    }

    public function ListPerticularBook($id)
    {
        $listPerticularBook = Book::where('b_id',$id)->get()->toArray();
        if (empty($listPerticularBook)) {
            $data = [];
            $data['data'] = 'Data Not Found';
            $data['status'] = false;
            return response()->json($data);
        } else {
            $data = [];
            $data['data'] = $listPerticularBook;
            $data['status'] = true;
            return response()->json($data);
        }
    }

}
