<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Model;
use App\Models\User;

class Book extends Model
{
    public $timestamps = false;
    use SoftDeletes;
    protected $fillable = ['b_id'];
    protected $primaryKey = 'b_id';

    public function user(){
        return $this->hasOne(User::class , 'book_user','b_id','u_id');
    }

}
