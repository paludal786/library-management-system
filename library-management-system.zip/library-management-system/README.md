## library-management-system
# relationship with jwt

- Download Project using git clone url

- run below command
1) compose install 
2) php artisan config:cache
3) php artisan route:list
4) php artisan serve
